﻿namespace TSP
{
    partial class TSPForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.operationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateMatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.peruseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MatrixDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MatrixPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.panelinput = new System.Windows.Forms.Panel();
            this.lblSubset = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.txtWMatrix = new System.Windows.Forms.TextBox();
            this.btnInto = new System.Windows.Forms.Button();
            this.txtRow = new System.Windows.Forms.Label();
            this.tableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.TabPageTSP = new System.Windows.Forms.TabControl();
            this.MatrixW = new System.Windows.Forms.TabPage();
            this.MatrixPanel = new System.Windows.Forms.Panel();
            this.SubSet = new System.Windows.Forms.TabPage();
            this.lblEnd = new System.Windows.Forms.Label();
            this.ListSubset = new System.Windows.Forms.ListBox();
            this.CalcTour = new System.Windows.Forms.TabPage();
            this.ListPath = new System.Windows.Forms.ListBox();
            this.DMatrix = new System.Windows.Forms.TabPage();
            this.Dpanel = new System.Windows.Forms.Panel();
            this.lblDCol = new System.Windows.Forms.Label();
            this.lblDRow = new System.Windows.Forms.Label();
            this.tableD = new System.Windows.Forms.TableLayoutPanel();
            this.PMatrix = new System.Windows.Forms.TabPage();
            this.Ppanel = new System.Windows.Forms.Panel();
            this.lblPcol = new System.Windows.Forms.Label();
            this.txtPRow = new System.Windows.Forms.Label();
            this.tableP = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1.SuspendLayout();
            this.panelinput.SuspendLayout();
            this.TabPageTSP.SuspendLayout();
            this.MatrixW.SuspendLayout();
            this.MatrixPanel.SuspendLayout();
            this.SubSet.SuspendLayout();
            this.CalcTour.SuspendLayout();
            this.DMatrix.SuspendLayout();
            this.Dpanel.SuspendLayout();
            this.PMatrix.SuspendLayout();
            this.Ppanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // operationToolStripMenuItem
            // 
            this.operationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputToolStripMenuItem,
            this.CreateMatToolStripMenuItem,
            this.peruseToolStripMenuItem,
            this.MatrixDToolStripMenuItem,
            this.MatrixPToolStripMenuItem});
            this.operationToolStripMenuItem.Name = "operationToolStripMenuItem";
            this.operationToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.operationToolStripMenuItem.Text = "عملیات پایه";
            // 
            // inputToolStripMenuItem
            // 
            this.inputToolStripMenuItem.Name = "inputToolStripMenuItem";
            this.inputToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.inputToolStripMenuItem.Text = "ماتریس مجاورت با مسیرهای تصادفی";
            this.inputToolStripMenuItem.Click += new System.EventHandler(this.inputToolStripMenuItem_Click);
            // 
            // CreateMatToolStripMenuItem
            // 
            this.CreateMatToolStripMenuItem.Name = "CreateMatToolStripMenuItem";
            this.CreateMatToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.CreateMatToolStripMenuItem.Text = "ایجاد ماتریس مجاورت گراف";
            this.CreateMatToolStripMenuItem.Click += new System.EventHandler(this.CreateMatToolStripMenuItem_Click);
            // 
            // peruseToolStripMenuItem
            // 
            this.peruseToolStripMenuItem.Enabled = false;
            this.peruseToolStripMenuItem.Name = "peruseToolStripMenuItem";
            this.peruseToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.peruseToolStripMenuItem.Text = "یافتن تور بهینه";
            this.peruseToolStripMenuItem.Click += new System.EventHandler(this.peruseToolStripMenuItem_Click);
            // 
            // MatrixDToolStripMenuItem
            // 
            this.MatrixDToolStripMenuItem.Enabled = false;
            this.MatrixDToolStripMenuItem.Name = "MatrixDToolStripMenuItem";
            this.MatrixDToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.MatrixDToolStripMenuItem.Text = "ماتریس D";
            this.MatrixDToolStripMenuItem.Click += new System.EventHandler(this.MatrixDToolStripMenuItem_Click);
            // 
            // MatrixPToolStripMenuItem
            // 
            this.MatrixPToolStripMenuItem.Enabled = false;
            this.MatrixPToolStripMenuItem.Name = "MatrixPToolStripMenuItem";
            this.MatrixPToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.MatrixPToolStripMenuItem.Text = "ماتریس P";
            this.MatrixPToolStripMenuItem.Click += new System.EventHandler(this.MatrixPToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.exitToolStripMenuItem.Text = "خروج";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.operationToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(785, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(8, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 14);
            this.label1.TabIndex = 3;
            this.label1.Text = "تعداد رئوس گراف موردنظر را وارد نمائید";
            // 
            // panelinput
            // 
            this.panelinput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelinput.Controls.Add(this.lblSubset);
            this.panelinput.Controls.Add(this.btnCreate);
            this.panelinput.Controls.Add(this.txtWMatrix);
            this.panelinput.Controls.Add(this.label1);
            this.panelinput.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelinput.Location = new System.Drawing.Point(570, 24);
            this.panelinput.Name = "panelinput";
            this.panelinput.Size = new System.Drawing.Size(215, 598);
            this.panelinput.TabIndex = 0;
            // 
            // lblSubset
            // 
            this.lblSubset.AutoSize = true;
            this.lblSubset.Location = new System.Drawing.Point(5, 64);
            this.lblSubset.Name = "lblSubset";
            this.lblSubset.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblSubset.Size = new System.Drawing.Size(56, 14);
            this.lblSubset.TabIndex = 4;
            this.lblSubset.Text = "lblSubset";
            // 
            // btnCreate
            // 
            this.btnCreate.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnCreate.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCreate.Location = new System.Drawing.Point(8, 25);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(92, 23);
            this.btnCreate.TabIndex = 1;
            this.btnCreate.Tag = "";
            this.btnCreate.Text = "ایجاد ماتریس";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // txtWMatrix
            // 
            this.txtWMatrix.Location = new System.Drawing.Point(102, 25);
            this.txtWMatrix.Name = "txtWMatrix";
            this.txtWMatrix.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtWMatrix.Size = new System.Drawing.Size(50, 22);
            this.txtWMatrix.TabIndex = 0;
            // 
            // btnInto
            // 
            this.btnInto.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.btnInto.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnInto.Location = new System.Drawing.Point(8, 7);
            this.btnInto.Name = "btnInto";
            this.btnInto.Size = new System.Drawing.Size(23, 23);
            this.btnInto.TabIndex = 35;
            this.btnInto.Tag = "";
            this.btnInto.Text = "∞";
            this.btnInto.UseVisualStyleBackColor = true;
            this.btnInto.Visible = false;
            this.btnInto.Click += new System.EventHandler(this.btnInto_Click);
            // 
            // txtRow
            // 
            this.txtRow.AutoSize = true;
            this.txtRow.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtRow.Location = new System.Drawing.Point(7, 36);
            this.txtRow.Name = "txtRow";
            this.txtRow.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRow.Size = new System.Drawing.Size(17, 16);
            this.txtRow.TabIndex = 5;
            this.txtRow.Text = "R";
            this.txtRow.Visible = false;
            // 
            // tableLayout
            // 
            this.tableLayout.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayout.ColumnCount = 1;
            this.tableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayout.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tableLayout.Location = new System.Drawing.Point(30, 28);
            this.tableLayout.Name = "tableLayout";
            this.tableLayout.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableLayout.RowCount = 1;
            this.tableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayout.Size = new System.Drawing.Size(38, 36);
            this.tableLayout.TabIndex = 5;
            this.tableLayout.Visible = false;
            // 
            // TabPageTSP
            // 
            this.TabPageTSP.Controls.Add(this.MatrixW);
            this.TabPageTSP.Controls.Add(this.SubSet);
            this.TabPageTSP.Controls.Add(this.CalcTour);
            this.TabPageTSP.Controls.Add(this.DMatrix);
            this.TabPageTSP.Controls.Add(this.PMatrix);
            this.TabPageTSP.Location = new System.Drawing.Point(9, 31);
            this.TabPageTSP.Name = "TabPageTSP";
            this.TabPageTSP.SelectedIndex = 0;
            this.TabPageTSP.Size = new System.Drawing.Size(551, 583);
            this.TabPageTSP.TabIndex = 2;
            // 
            // MatrixW
            // 
            this.MatrixW.BackColor = System.Drawing.Color.Yellow;
            this.MatrixW.Controls.Add(this.MatrixPanel);
            this.MatrixW.Location = new System.Drawing.Point(4, 23);
            this.MatrixW.Name = "MatrixW";
            this.MatrixW.Padding = new System.Windows.Forms.Padding(3);
            this.MatrixW.Size = new System.Drawing.Size(543, 556);
            this.MatrixW.TabIndex = 2;
            this.MatrixW.Text = "ماتریس مجاورت گراف";
            this.MatrixW.UseVisualStyleBackColor = true;
            // 
            // MatrixPanel
            // 
            this.MatrixPanel.Controls.Add(this.btnInto);
            this.MatrixPanel.Controls.Add(this.txtRow);
            this.MatrixPanel.Controls.Add(this.tableLayout);
            this.MatrixPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MatrixPanel.Location = new System.Drawing.Point(3, 3);
            this.MatrixPanel.Name = "MatrixPanel";
            this.MatrixPanel.Size = new System.Drawing.Size(537, 550);
            this.MatrixPanel.TabIndex = 36;
            // 
            // SubSet
            // 
            this.SubSet.BackColor = System.Drawing.Color.Khaki;
            this.SubSet.Controls.Add(this.lblEnd);
            this.SubSet.Controls.Add(this.ListSubset);
            this.SubSet.Location = new System.Drawing.Point(4, 23);
            this.SubSet.Name = "SubSet";
            this.SubSet.Padding = new System.Windows.Forms.Padding(3);
            this.SubSet.Size = new System.Drawing.Size(543, 556);
            this.SubSet.TabIndex = 1;
            this.SubSet.Text = "زیرمجموعه ها بدون راس مبدا";
            // 
            // lblEnd
            // 
            this.lblEnd.AutoSize = true;
            this.lblEnd.Location = new System.Drawing.Point(6, 540);
            this.lblEnd.Name = "lblEnd";
            this.lblEnd.Size = new System.Drawing.Size(64, 14);
            this.lblEnd.TabIndex = 38;
            this.lblEnd.Text = "lblEndPath";
            // 
            // ListSubset
            // 
            this.ListSubset.BackColor = System.Drawing.Color.Yellow;
            this.ListSubset.Dock = System.Windows.Forms.DockStyle.Top;
            this.ListSubset.FormattingEnabled = true;
            this.ListSubset.ItemHeight = 14;
            this.ListSubset.Location = new System.Drawing.Point(3, 3);
            this.ListSubset.Name = "ListSubset";
            this.ListSubset.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ListSubset.Size = new System.Drawing.Size(537, 536);
            this.ListSubset.TabIndex = 37;
            // 
            // CalcTour
            // 
            this.CalcTour.Controls.Add(this.ListPath);
            this.CalcTour.Location = new System.Drawing.Point(4, 23);
            this.CalcTour.Name = "CalcTour";
            this.CalcTour.Padding = new System.Windows.Forms.Padding(3);
            this.CalcTour.Size = new System.Drawing.Size(543, 556);
            this.CalcTour.TabIndex = 0;
            this.CalcTour.Text = "محاسبه تور بهینه";
            this.CalcTour.UseVisualStyleBackColor = true;
            // 
            // ListPath
            // 
            this.ListPath.BackColor = System.Drawing.Color.Yellow;
            this.ListPath.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListPath.FormattingEnabled = true;
            this.ListPath.ItemHeight = 14;
            this.ListPath.Location = new System.Drawing.Point(3, 3);
            this.ListPath.Name = "ListPath";
            this.ListPath.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ListPath.Size = new System.Drawing.Size(537, 550);
            this.ListPath.TabIndex = 2;
            // 
            // DMatrix
            // 
            this.DMatrix.BackColor = System.Drawing.Color.Khaki;
            this.DMatrix.Controls.Add(this.Dpanel);
            this.DMatrix.Location = new System.Drawing.Point(4, 23);
            this.DMatrix.Name = "DMatrix";
            this.DMatrix.Size = new System.Drawing.Size(543, 556);
            this.DMatrix.TabIndex = 3;
            this.DMatrix.Text = "ماتریس D";
            // 
            // Dpanel
            // 
            this.Dpanel.AutoScroll = true;
            this.Dpanel.Controls.Add(this.lblDCol);
            this.Dpanel.Controls.Add(this.lblDRow);
            this.Dpanel.Controls.Add(this.tableD);
            this.Dpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Dpanel.Location = new System.Drawing.Point(0, 0);
            this.Dpanel.Name = "Dpanel";
            this.Dpanel.Size = new System.Drawing.Size(543, 556);
            this.Dpanel.TabIndex = 0;
            // 
            // lblDCol
            // 
            this.lblDCol.AutoSize = true;
            this.lblDCol.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDCol.Location = new System.Drawing.Point(55, 9);
            this.lblDCol.Name = "lblDCol";
            this.lblDCol.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblDCol.Size = new System.Drawing.Size(16, 16);
            this.lblDCol.TabIndex = 8;
            this.lblDCol.Text = "C";
            // 
            // lblDRow
            // 
            this.lblDRow.AutoSize = true;
            this.lblDRow.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblDRow.Location = new System.Drawing.Point(5, 36);
            this.lblDRow.Name = "lblDRow";
            this.lblDRow.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblDRow.Size = new System.Drawing.Size(17, 16);
            this.lblDRow.TabIndex = 7;
            this.lblDRow.Text = "R";
            this.lblDRow.Visible = false;
            // 
            // tableD
            // 
            this.tableD.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableD.ColumnCount = 1;
            this.tableD.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableD.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tableD.Location = new System.Drawing.Point(30, 28);
            this.tableD.Name = "tableD";
            this.tableD.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableD.RowCount = 1;
            this.tableD.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableD.Size = new System.Drawing.Size(38, 36);
            this.tableD.TabIndex = 6;
            this.tableD.Visible = false;
            // 
            // PMatrix
            // 
            this.PMatrix.BackColor = System.Drawing.Color.Khaki;
            this.PMatrix.Controls.Add(this.Ppanel);
            this.PMatrix.Location = new System.Drawing.Point(4, 23);
            this.PMatrix.Name = "PMatrix";
            this.PMatrix.Size = new System.Drawing.Size(543, 556);
            this.PMatrix.TabIndex = 4;
            this.PMatrix.Text = "ماتریس P";
            // 
            // Ppanel
            // 
            this.Ppanel.AutoScroll = true;
            this.Ppanel.AutoSize = true;
            this.Ppanel.Controls.Add(this.lblPcol);
            this.Ppanel.Controls.Add(this.txtPRow);
            this.Ppanel.Controls.Add(this.tableP);
            this.Ppanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ppanel.Location = new System.Drawing.Point(0, 0);
            this.Ppanel.Name = "Ppanel";
            this.Ppanel.Size = new System.Drawing.Size(543, 556);
            this.Ppanel.TabIndex = 0;
            // 
            // lblPcol
            // 
            this.lblPcol.AutoSize = true;
            this.lblPcol.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lblPcol.Location = new System.Drawing.Point(55, 9);
            this.lblPcol.Name = "lblPcol";
            this.lblPcol.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblPcol.Size = new System.Drawing.Size(16, 16);
            this.lblPcol.TabIndex = 10;
            this.lblPcol.Text = "C";
            // 
            // txtPRow
            // 
            this.txtPRow.AutoSize = true;
            this.txtPRow.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtPRow.Location = new System.Drawing.Point(5, 36);
            this.txtPRow.Name = "txtPRow";
            this.txtPRow.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtPRow.Size = new System.Drawing.Size(17, 16);
            this.txtPRow.TabIndex = 9;
            this.txtPRow.Text = "R";
            this.txtPRow.Visible = false;
            // 
            // tableP
            // 
            this.tableP.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableP.ColumnCount = 1;
            this.tableP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableP.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.tableP.Location = new System.Drawing.Point(30, 28);
            this.tableP.Name = "tableP";
            this.tableP.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tableP.RowCount = 1;
            this.tableP.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableP.Size = new System.Drawing.Size(38, 36);
            this.tableP.TabIndex = 8;
            this.tableP.Visible = false;
            // 
            // TSPForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(785, 622);
            this.ControlBox = false;
            this.Controls.Add(this.TabPageTSP);
            this.Controls.Add(this.panelinput);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TSPForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فروشنده دوره گرد";
            this.Load += new System.EventHandler(this.TSPForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelinput.ResumeLayout(false);
            this.panelinput.PerformLayout();
            this.TabPageTSP.ResumeLayout(false);
            this.MatrixW.ResumeLayout(false);
            this.MatrixPanel.ResumeLayout(false);
            this.MatrixPanel.PerformLayout();
            this.SubSet.ResumeLayout(false);
            this.SubSet.PerformLayout();
            this.CalcTour.ResumeLayout(false);
            this.DMatrix.ResumeLayout(false);
            this.Dpanel.ResumeLayout(false);
            this.Dpanel.PerformLayout();
            this.PMatrix.ResumeLayout(false);
            this.PMatrix.PerformLayout();
            this.Ppanel.ResumeLayout(false);
            this.Ppanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem operationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inputToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem peruseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelinput;
        private System.Windows.Forms.TableLayoutPanel tableLayout;
        private System.Windows.Forms.Label txtRow;
        private System.Windows.Forms.Button btnInto;
        private System.Windows.Forms.TextBox txtWMatrix;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.ToolStripMenuItem CreateMatToolStripMenuItem;
        private System.Windows.Forms.TabControl TabPageTSP;
        private System.Windows.Forms.TabPage CalcTour;
        private System.Windows.Forms.TabPage SubSet;
        private System.Windows.Forms.ListBox ListSubset;
        private System.Windows.Forms.TabPage MatrixW;
        private System.Windows.Forms.Panel MatrixPanel;
        private System.Windows.Forms.Label lblEnd;
        private System.Windows.Forms.ListBox ListPath;
        private System.Windows.Forms.TabPage DMatrix;
        private System.Windows.Forms.TabPage PMatrix;
        private System.Windows.Forms.Panel Dpanel;
        private System.Windows.Forms.Panel Ppanel;
        private System.Windows.Forms.Label lblDRow;
        private System.Windows.Forms.TableLayoutPanel tableD;
        private System.Windows.Forms.Label txtPRow;
        private System.Windows.Forms.TableLayoutPanel tableP;
        private System.Windows.Forms.ToolStripMenuItem MatrixDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MatrixPToolStripMenuItem;
        private System.Windows.Forms.Label lblSubset;
        private System.Windows.Forms.Label lblDCol;
        private System.Windows.Forms.Label lblPcol;

    }
}

