﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TSP
{
    public partial class TSPForm : Form
    {
        public int n;
        public TextBox[,] tb;
        public Label[] lb;
        public int[,] matW;
        public int[,] D;
        public int[,] P;
        public string[] TotalSubset;
        public string[] A;
        public int[] Path;
        public int[] min;
        
        public TextBox CurrentTextBox { get; set; }

        public TSPForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //جستجوی وجود گروه مسیرها
        int ReturnSetNum(string StrSearch)
        {
            for (int i = 1; i < TotalSubset.Length; i++)
                if (TotalSubset[i]==StrSearch)
                    return i;
            return 0;
        }

        int Minimum(int []arrMin)
        {
            int min = arrMin[0];
            for (int i = 1; i < arrMin.Length; i++)
            {
                if (arrMin[i] == 0)
                    continue;
                if (arrMin[i] < min)
                    min = arrMin[i];
            }
            return min;
        }

        int SearchItem(int item, int[] Path)
        {
            for (int i = 0; i < Path.Length; i++)
            {
                if (item == Path[i])
                    return 1;
            }
            return 0;
        }

        int SearchIndex(int item, string Subset)
        {
            string[] tmp = new string[(int)Math.Pow(2, n - 1)];
            tmp = Subset.Split(new char[] { ' ' }, ' ');
            for (int i = 0; i < tmp.Length; i++)
            {
                if (Convert.ToString(item) == tmp[i])
                    return 1;
            }
            return 0;
        }

        //جداسازی مسیرهای مختلف مجموعه آ
        private void SeperatePath(string APath)
        {
            int ind = 0;
            Path = new int[(int)Math.Pow(2, n - 1)];
            string[] tmp = new string[(int)Math.Pow(2, n - 1)];
            tmp = APath.Split(new char[] { ' ' }, ' ');
            for (int i = 0; i < tmp.Length ; i++)
            {
                if (tmp[i]!="")
                {
                    Path[ind] = int.Parse(tmp[i]);
                    ind++;
                }
            }
            //Path = tmp;
        }

        //جداسازی مجموعه های چند عضوی در مجموعه آ
        private void SeperateElement(int Element)
        {
            int ind = 0;
            A = new string[(int)Math.Pow(2, n - 1)];
            string[] tmp = new string[(int)Math.Pow(2, n - 1)];
            for (int i = 1; i < TotalSubset.Length; i++)
            {
                tmp = TotalSubset[i].Split(new char[] { ' ' }, ' ');
                if (tmp.Length == Element)
                {
                    A[ind] = TotalSubset[i];
                    ind++;
                }
            }
        }

        string SeperatePathDes(int item, string Subset)
        {
            string[] tmp = new string[(int)Math.Pow(2, n - 1)];
            string res ="";
            tmp = Subset.Split(new char[] { ' ' }, ' ');
            for (int i = 0; i < tmp.Length; i++)
            {
                if (item != int.Parse(tmp[i]))
                    res += tmp[i] + " ";
            }
            return res;
        }

        string Item(int x)
        {
            if (x == 999)
                return "∞";
            else
                return (Convert.ToString(x));
        }

        private void Travel()
        {
            int index = 0, ind = 0;
            D = new int[n, (int)Math.Pow(2, n - 1)];
            P = new int[n, (int)Math.Pow(2, n - 1)];
            for (int i = 1; i < n; i++)
            {
                D[i, 0] = matW[i, 0];
                if (D[i, 0] == 999) ListPath.Items.Add("D[V" + Convert.ToString(i) + "][{ Ø }] = ∞");
                else ListPath.Items.Add("D[V" + Convert.ToString(i) + "][{ Ø }] = " + Convert.ToString(D[i, 0]));
            }
            for (int k = 1; k <= n - 2; k++)
            {
                ListPath.Items.Add("");
                SeperateElement(k);     //مجموعه های کا عضوی
                for (int i = 1; i < n; i++)
                {
                    for (int j = 0; A[j] != null; j++)
                    {
                        ind = 0;
                        SeperatePath(A[j]);
                        if (1 == SearchItem(i, Path))
                            continue;
                        min = new int[Path.Length];
                        for (int p = 0; Path[p]!=0 ; p++)
                        {
                            if (k == 1)
                            {
                                min[ind] = matW[i, Path[p]] + D[Path[p], ReturnSetNum("")];
                                if (matW[i, Path[p]] == 999 || D[Path[p], ReturnSetNum("")] == 999)
                                    min[ind] = 999;
                                index = ReturnSetNum(A[j]);
                                D[i, ReturnSetNum(A[j])] = Minimum(min);
                                ListPath.Items.Add("D[V" + Item(i) + "][{ " + A[j] + " }] = "
                                    + "W[" + Item(i) + "][" + Item(Path[p]) + "]"
                                    + " + D[V" + Item(Path[p]) + "][{ Ø }] = "
                                    + Item(matW[i, Path[p]]) + " + " + Item(D[Path[p], ReturnSetNum("")]) + " = "
                                    + Item(D[i, index]));
                                //ListPath.Items.Add("D[V" + Convert.ToString(i) + "][{ " + A[j] + " }] = "
                                //    + "W[" + Convert.ToString(i) + "][" + Convert.ToString(Path[p]) + "]"
                                //    + " + D[V" + Convert.ToString(Path[p]) + "][{ Ø }] = "
                                //    + Convert.ToString(matW[i, Path[p]]) + " + " + Convert.ToString(D[Path[p], ReturnSetNum("")])+" = "
                                //    + Convert.ToString(D[i, index]));
                                ind++;
                            }
                            for (int q = 0; Path[q]!=0 ; q++)
                            {
                                if (Path[p] == Path[q])
                                    continue;
                                string des = SeperatePathDes(Path[p], A[j]);
                                des = des.Trim(' ');
                                index = ReturnSetNum(des);
                                min[ind] = matW[i, Path[p]] + D[Path[p], index];
                                if (matW[i, Path[p]] == 999 || D[Path[p], index] == 999)
                                    min[ind] = 999;
                                ind++;
                                D[i, ReturnSetNum(A[j])] = Minimum(min);
                                ListPath.Items.Add("D[V" + Item(i) + "][{ " + A[j] + " }] = "
                                    + "W[" + Item(i) + "][" + Item(Path[p]) + "]"
                                    + " + D[V" + Item(Path[p]) + "][{ " + des + " }] = "
                                    + Item(matW[i, Path[p]]) + " + " + Item(D[Path[p], index]) + " = "
                                    + Item(D[i, ReturnSetNum(A[j])]));
                                //ListPath.Items.Add("D[V" + Convert.ToString(i) + "][{ " + A[j] + " }] = "
                                //    + "W[" + Convert.ToString(i) + "][" + Convert.ToString(Path[p]) + "]"
                                //    + " + D[V" + Convert.ToString(Path[p]) + "][{ " + des + " }] = "
                                //    + Convert.ToString(matW[i, Path[p]]) + " + " + Convert.ToString(D[Path[p], index]) + " = "
                                //    + Convert.ToString(D[i, ReturnSetNum(A[j])]));
                            }
                            P[i, ReturnSetNum(A[j])] = Minimum(Path);
                        }
                    }
                }
            }
            ind = 0;
            ListPath.Items.Add("");
            SeperatePath(TotalSubset[TotalSubset.Length - 1]);
            min = new int[Path.Length];
            for (int i = 1; i <= n - 1; i++)
            {
                SeperateElement(n - 2);
                for (int j = 0; Path[j] != 0; j++)
                {
                    if (1 == SearchIndex(i, A[j]))
                        continue;
                    index = ReturnSetNum(A[j]);
                    min[ind] = matW[0, i] + D[i, index];
                    if (matW[0, i] == 999 || D[i, index] == 999)
                        min[ind] = 999;
                    ind++;
                }
                D[0, ReturnSetNum(TotalSubset[TotalSubset.Length - 1])] = Minimum(min);
                ListPath.Items.Add("D[V0][{ " + TotalSubset[TotalSubset.Length - 1] + " }] = "
                   + "W[0][" + Item(i) + "]"
                   + " + D[V" + Item(i) + "][{ " + A[i - 1] + " }] = "
                   + Item(matW[0, i]) + " + " + Item(D[i, index]) + " = "
                   + Item(D[0, ReturnSetNum(TotalSubset[TotalSubset.Length - 1])]));
                //ListPath.Items.Add("D[V0][{ " + TotalSubset[TotalSubset.Length - 1] + " }] = "
                //   + "W[0][" + Convert.ToString(i) + "]"
                //   + " + D[V" + Convert.ToString(i) + "][{ " + A[i - 1] + " }] = "
                //   + Convert.ToString(matW[0, i]) + " + " + Convert.ToString(D[i, index]) + " = "
                //   + Convert.ToString(D[0, ReturnSetNum(TotalSubset[TotalSubset.Length - 1])]));
            }
            P[0, ReturnSetNum(TotalSubset[TotalSubset.Length - 1])] = Minimum(Path);
        }

        private void peruseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListPath.Items.Clear();
            Travel();
            peruseToolStripMenuItem.Enabled = false;
            MatrixDToolStripMenuItem.Enabled = true;
            MatrixPToolStripMenuItem.Enabled = true;
            TabPageTSP.SelectedTab = CalcTour;
        }

        private void ShowDMatrix()
        {
            int index = 0;
            lblDRow.Text = "";
            lblDRow.Visible = true;
            tableD.Visible = true;
            TextBox[,] tbd = new TextBox[n, (int)Math.Pow(2, n-1)];
            tableD.ColumnCount = (int)Math.Pow(2, n - 1);
            tableD.RowCount = n;
            tableD.Height = n * 32;
            tableD.Width = n * 116;
            for (int i = 0; i < n ; i++)
            {
                for (int j = 0; j < (int)Math.Pow(2, n - 1) ; j++)
                {
                    tbd[i, j] = new TextBox();
                    tbd[i, j].RightToLeft = RightToLeft.No;
                    tbd[i, j].BackColor = Color.SandyBrown;
                    tbd[i, j].Font = new Font("Tahoma", 10);
                    tbd[i, j].Size = new Size(50, 23);
                    tbd[i, j].Name = "T" + Convert.ToString(i);
                    tableD.Controls.Add(tbd[i, j]);
                    if (D[i, j] == 999)
                    {
                        tableD.Controls[index].Text = "∞";
                        index += 1;
                        continue;
                    }
                    if (D[i, j] == 0)
                    {
                        tableD.Controls[index].Text = "-";
                        index += 1;
                        continue;
                    }
                    tableD.Controls[index].Text = Convert.ToString(D[i, j]);
                    index += 1;
                }
                lblDRow.Text += Convert.ToString(i) + "\r\n\n";
            }
            lblDCol.Text = "";
            for (int i = 0; i < TotalSubset.Length; i++) 
                lblDCol.Text += Convert.ToString(i) + "            ";
            lblSubset.Text = "";
            for (int i = 0; i < TotalSubset.Length; i++)
                lblSubset.Text +=Convert.ToString(i)+". { "+ TotalSubset[i] + " }\r\n";
        }

        private void ShowPMatrix()
        {
            int index = 0;
            txtPRow.Text = "";
            txtPRow.Visible = true;
            tableP.Visible = true;
            TextBox[,] tbp = new TextBox[n, (int)Math.Pow(2, n - 1)];
            tableP.ColumnCount = (int)Math.Pow(2, n - 1);
            tableP.RowCount = n;
            tableP.Height = n * 32;
            tableP.Width = n * 116;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < (int)Math.Pow(2, n - 1); j++)
                {
                    tbp[i, j] = new TextBox();
                    tbp[i, j].RightToLeft = RightToLeft.No;
                    tbp[i, j].BackColor = Color.SandyBrown;
                    tbp[i, j].Font = new Font("Tahoma", 10);
                    tbp[i, j].Size = new Size(50, 23);
                    tbp[i, j].Name = "T" + Convert.ToString(i);
                    tableP.Controls.Add(tbp[i, j]);
                    if (P[i, j] == 999)
                    {
                        tableP.Controls[index].Text = "∞";
                        index += 1;
                        continue;
                    }
                    if (P[i, j] == 0)
                    {
                        tableP.Controls[index].Text = "-";
                        index += 1;
                        continue;
                    }
                    tableP.Controls[index].Text = Convert.ToString(P[i, j]);
                    index += 1;
                }
                txtPRow.Text += Convert.ToString(i) + "\r\n\n";
            }
            for (int i = 0; i < TotalSubset.Length; i++) 
                lblPcol.Text += Convert.ToString(i) + "            ";
            lblSubset.Text = "";
            for (int i = 0; i < TotalSubset.Length; i++)
                lblSubset.Text += Convert.ToString(i) + ". { " + TotalSubset[i] + " }\r\n";
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            int index = 0;
            if (txtWMatrix.Text != "" && int.Parse(txtWMatrix.Text)<=16)
            {
                txtRow.Text = "";
                for (int i = 0; i < n; i++)
                    MatrixPanel.Controls.Remove(lb[i]);
                for (int i = 0; i < n * n; i++)
                    tableLayout.Controls.Clear();
                tableLayout.Visible = true;
                txtRow.Visible = true;
                n = int.Parse(txtWMatrix.Text);
                tb = new TextBox[n, n];
                lb = new Label[n];
                tableLayout.ColumnCount = n;
                tableLayout.RowCount = n;
                tableLayout.Height = n * 32;
                tableLayout.Width = n * 31;
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        tb[i, j] = new TextBox();
                        tb[i, j].RightToLeft = RightToLeft.No;
                        tb[i, j].BackColor = Color.SandyBrown;
                        tb[i, j].Font = new Font("Tahoma", 10);
                        tb[i, j].Size = new Size(23, 23);
                        tb[i, j].Name = "T" + Convert.ToString(i);
                        tb[i, j].Enter += new EventHandler(textBox_Enter);
                        tb[i, j].Text = Convert.ToString(i + 1);        //hazf shavad...
                        tableLayout.Controls.Add(tb[i, j]);
                        if (i == j)
                        {
                            tableLayout.Controls[index].Text = "0";
                            tb[i, j].BackColor = Color.Teal;
                            tableLayout.Controls[index].Enabled = false;
                            index += (n + 1);
                        }
                    }
                    txtRow.Text += Convert.ToString(i) + "\r\n\n";
                }
                int space = tableLayout.Width / n;
                int x = 39;
                for (int i = 0; i < n; i++)
                {
                    lb[i] = new Label();
                    lb[i].AutoSize = true;
                    lb[i].RightToLeft = RightToLeft.No;
                    lb[i].Font = new Font("Tahoma", 9,FontStyle.Bold);
                    lb[i].Name = "L" + Convert.ToString(i);
                    lb[i].Text = Convert.ToString(i);
                    lb[i].Location = new Point(x, 10);
                    MatrixPanel.Controls.Add(lb[i]);
                    x += space;
                }
                btnInto.Visible = true;
            }
        }

        private void CreateMatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = 0;
            matW = new int[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    if (tableLayout.Controls[index].Text == "∞" || tableLayout.Controls[index].Text == "")
                        matW[i, j] = 999;       //meghdar binahayat
                    else
                        matW[i, j] = int.Parse(tableLayout.Controls[index].Text);
                    index++;
                }
            peruseToolStripMenuItem.Enabled = true;

            TotalSubset = new string[(int)Math.Pow(2, n - 1)];
            ListSubset.Items.Clear();
            int[] node = new int[n];
            for (int i = 0; i < n ; i++)
                node[i] = i;
            for (int i = 0; i < Math.Pow(2, n - 1); i++)
            {
                string Set = "";
                string str = Convert.ToString(i, 2);
                for (int j = str.Length; j < n - 1; j++) str = str.Insert(0, "0");
                for (int k = 0; k < str.Length; k++)
                {
                    string spl = str.Substring(k, 1);
                    if (spl == "1")
                        Set += Convert.ToString(node[k+1]) + " ";
                }
                TotalSubset[i] = Set;
            }
            SortSubset(TotalSubset);
            for (int i = 0; i < TotalSubset.Length; i++) TotalSubset[i] = TotalSubset[i].Trim(' ');
            for (int i = 0; i < Math.Pow(2, n - 1); i++)
                ListSubset.Items.Add("{ " + TotalSubset[i] + " }\r\n");
            TabPageTSP.SelectedTab = SubSet;
        }

        private void SortSubset(string[] A)
        {
            string temp;
            for (int i = 0; i < A.Length; i++)
                for (int j = 1; j < A.Length; j++)
                {
                    if (A[j].Length < A[j - 1].Length)
                    {
                        temp = A[j];
                        A[j] = A[j - 1];
                        A[j - 1] = temp;
                    }
                }
        }

        private void inputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            for (int i = 0; i < n * n; i++)
            {
                if (i % (n + 1) == 0)
                {
                    tableLayout.Controls[i].Enabled = false;
                    continue;
                }
                tableLayout.Controls[i].Text = Convert.ToString(r.Next(1, 10));
            }
        }

        private void textBox_Enter(object sender, EventArgs e)
        {
            CurrentTextBox = (TextBox)sender;
        }

        private void btnInto_Click(object sender, EventArgs e)
        {
            if (CurrentTextBox != null)
                CurrentTextBox.Text = btnInto.Text;
        }

        private void txtWMatrix_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void MatrixDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowDMatrix();
            TabPageTSP.SelectedTab = DMatrix;
        }

        private void MatrixPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowPMatrix();
            TabPageTSP.SelectedTab = PMatrix;
        }

        private void TSPForm_Load(object sender, EventArgs e)
        {
            lblPcol.Text = "";
            lblDCol.Text = "";
            lblSubset.Text = "";
        }

    }
}
